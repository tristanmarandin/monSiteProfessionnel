This project aims to create an assistant to play poker in online tournaments. 
Pookie by name, has to guide the player on the reaction he should have to maximise his chances to win. 
This way, the AI must suggest to fold, check, call, bet or raise depending on the situation, and indicate a chip amount in case of a bet or a rise.

To use it, all you have to do is to follow these instructions :
1. Run the JupyterNotebook createDataBase to create the dataset that will be used to train Pookie.
2. Run the JupyterNotebook createModel to train Pookie.
3. Inform about the features Pookie is asking you for.